import pandas as pd
import re
import numpy as np
from nltk.corpus import stopwords, wordnet
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.stem import WordNetLemmatizer, PorterStemmer
import nltk

def clean_text(text, STOPWORDS):
    REPLACE_BY_SPACE_RE = re.compile('[/(){}\[\]\|@,;]')
    BAD_SYMBOLS_RE = re.compile('[^0-9a-z #+_]')
    text = text.lower() # lowercase text
    text = ' '.join(word for word in text.split() if word not in STOPWORDS)
    text = REPLACE_BY_SPACE_RE.sub(' ', text) # replace REPLACE_BY_SPACE_RE symbols by space in text
    text = BAD_SYMBOLS_RE.sub('', text) # delete symbols which are in BAD_SYMBOLS_RE from text
    text = ' '.join(word for word in text.split() if word not in STOPWORDS) # delete stopwors from text
    return text

def kill_numbers(text):
    split = text.split()
    split = ['' if i.isdigit() and len(i)<20 else i for i in split]
    join = ' '.join(split).strip()
    return join

def kill_more_numbers(text):
    text = text.split()
    pattern = '[0-9]'
    l = [re.sub(pattern, '', i) for i in text]
    output = ' '.join(l)
    return output

def get_wordnet_pos(treebank_tag):

    if treebank_tag.startswith('J'):
        return wordnet.ADJ
    elif treebank_tag.startswith('V'):
        return wordnet.VERB
    elif treebank_tag.startswith('N'):
        return wordnet.NOUN
    elif treebank_tag.startswith('R'):
        return wordnet.ADV
    else:
        return ''

def lemmatize_df(txt):
    tokenized = sent_tokenize(txt) 
    try:
        for i in tokenized: 
            if i.isdigit():
                i = ''
            wordsList = nltk.word_tokenize(i) 
            wordsList = [w for w in wordsList if not w in set(stopwords)]    
            tag = nltk.pos_tag(wordsList)
        lemmatizer = WordNetLemmatizer() 
        tagged = [(i[0], i[1].replace(i[1], get_wordnet_pos(i[1]))) for i in tag]
        tagged = [(i[0], i[1]) if i[1]!='' else (i[0], 'n') for i in tagged]
        row = [lemmatizer.lemmatize(i[0], pos=i[1]) for i in tagged]
        row = ' '.join(row)
        return row
    except:
        return txt

def remove_single_letter(text):
    text = text.split()
    out = [i for i in text if len(i)>1]
    out = ' '.join(out)
    return out


