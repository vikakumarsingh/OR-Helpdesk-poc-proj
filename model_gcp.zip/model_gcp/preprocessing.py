import numpy as np
import pickle
import nltk
import pandas as pd
from common_function import clean_text,kill_numbers,kill_more_numbers,lemmatize_df,remove_single_letter


class Vectorize(object):
    """Stores means of each column of a matrix and uses them for preprocessing.
    """

    def __init__(self,vectorizer):
        """On initialization, is not tied to any distribution."""
        self._vectorizer = vectorizer
        pass
    
    def preprocess(self, string):
        remove_words = ["repro steps", "defect", "description", "steps", "actual", "issue", "environment", "application","number", "stl1", "case","no", "case", "expected", "screen", "steps to repro", "casenumber", "summary", "steps","to","reproduce", "application", "case no", "actual", "expected","result", "actual","result"]
        remove_words_cap = [word.title() for word in remove_words]
        remove_words=remove_words + remove_words_cap
        stopwords = nltk.corpus.stopwords.words('english')
        newStopWords =remove_words
        stopwords.extend(newStopWords)

        """Transforms a matrix.
        The first time this is called, it stores the means of each column of
        the input. Then it transforms the input so each column has mean 0. For
        subsequent calls, it subtracts the stored means from each column. This
        lets you 'center' data at prediction time based on the distribution of
        the original training data.
        Args:
            data: A NumPy matrix of numerical data.
        Returns:
            A transformed matrix with the same dimensions as the input.
        """
        d = pd.DataFrame({'Repro Steps': [string]})
        d['Repro Steps'] = d['Repro Steps'].astype(str).map(lambda x: clean_text(x, set(stopwords)))
        d['Repro Steps'] = d['Repro Steps'].apply(lambda x: kill_numbers(x))
        d['Repro Steps'] = d['Repro Steps'].apply(lambda x: kill_more_numbers(x))
        d['Repro Steps'] = d['Repro Steps'].astype(str).apply(lambda x: lemmatize_df(x))
        d['Repro Steps'] = d['Repro Steps'].astype(str).apply(lambda x: remove_single_letter(x))
        d = d[d['Repro Steps']!='']
        d = d[d['Repro Steps']!=' ']
        d_vectors = self._vectorizer.transform(d['Repro Steps'].astype(str))
        feature_names = self._vectorizer.get_feature_names()
        dense = d_vectors.todense()
        denselist = dense.tolist()
        demo_test = pd.DataFrame(denselist, columns=feature_names)
        return demo_test
