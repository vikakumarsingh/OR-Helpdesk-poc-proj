import os
import pickle
import pandas as pd
import joblib
import numpy as np
from preprocessing import Vectorize

class MyPredictor(object):
    """An example Predictor for an AI Platform custom prediction routine."""

    def __init__(self, model, vectorizer):
        """Stores artifacts for prediction. Only initialized via `from_path`.
        """
        self._model = model
        self._preprocessor = Vectorize(vectorizer)

    def predict(self, instances, **kwargs):
        """Performs custom prediction.

        Preprocesses inputs, then performs prediction using the trained
        scikit-learn model.

        Args:
            instances: A list of prediction input instances.
            **kwargs: A dictionary of keyword args provided as additional
                fields on the predict request body.

        Returns:
            A list of outputs containing the prediction results.
        """
        category_list=['NMAGI','RFI','SNAP']
        inputs = np.asarray(instances)
        df = pd.DataFrame()
        for i in inputs:
            df = df.append(self._preprocessor.preprocess(i), ignore_index=True)
        # preprocessed_inputs = self._preprocessor.preprocess(inputs)
        outputs = self._model.predict_proba(df)
        output_list = outputs.ravel().tolist()
        index = []
        for i in range(0,3):
            if output_list[i] > 0.33:
                index.append(i)
        category=[]
        for i in index:
            category.append(category_list[i])
        return category

    @classmethod
    def from_path(cls, model_dir):
        """Creates an instance of MyPredictor using the given path.

        This loads artifacts that have been copied from your model directory in
        Cloud Storage. MyPredictor uses them during prediction.

        Args:
            model_dir: The local directory that contains the trained
                scikit-learn model and the pickled preprocessor instance. These
                are copied from the Cloud Storage model directory you provide
                when you deploy a version resource.

        Returns:
            An instance of `MyPredictor`.
        """
        model_path = os.path.join(model_dir, 'model.joblib')
        model = joblib.load(model_path)

        vectorizer_path = os.path.join(model_dir, 'vectorizer.pickle')
        with open(vectorizer_path, 'rb') as f:
            vectorizer = pickle.load(f)

        return cls(model, vectorizer)